

<?php $__env->startSection('container'); ?>
<div class="container">
    <br>
    <h1>Hasil Pesanan</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Nama Menu</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Nama Pemesan</th>
                <th>Alamat</th>
                <th>No. HP\WA</th>
                <th>Email</th>
                <th>Tanggal Pesan</th>
                <th hidden>Status</th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <th>Opsi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->menu ? $order->menu->name : 'Menu tidak ditemukan'); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td>Rp. <?php echo e($order ? number_format($order->grand_total, 2, ',', '.') : '0'); ?></td>
                <td><?php echo e($order->name); ?></td>
                <td><?php echo e($order->address); ?></td>
                <td><?php echo e($order->phone); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->created_at->format('d-m-Y H:i')); ?></td>
                <td hidden>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                    <form action="<?php echo e(route('dashboard.admin.orders.updateStatus', $order)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <select name="status" onchange="this.form.submit()">
                            <option value="Baru" <?php echo e($order->status == 'Baru' ? 'selected' : ''); ?>>Baru</option>
                            <option value="Diproses" <?php echo e($order->status == 'Diproses' ? 'selected' : ''); ?>>Diproses</option>
                            <option value="Diantar" <?php echo e($order->status == 'Diantar' ? 'selected' : ''); ?>>Diantar</option>
                            <option value="Dilokasi" <?php echo e($order->status == 'Dilokasi' ? 'selected' : ''); ?>>Dilokasi</option>
                            <option value="Selesai" <?php echo e($order->status == 'Selesai' ? 'selected' : ''); ?>>Selesai</option>
                        </select>
                    </form>
                    <?php else: ?>
                    <span><?php echo e(ucfirst($order->status)); ?></span>
                    <?php endif; ?>
                </td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <td>
                    <form action="<?php echo e(route('dashboard.admin.orders.destroy', $order)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pesanan ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                    <a href="<?php echo e(route('dashboard.admin.orders.nota', $order)); ?>" class="btn btn-info">Nota</a> <!-- Tambahkan tombol Nota -->
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/admin/orders/index.blade.php ENDPATH**/ ?>