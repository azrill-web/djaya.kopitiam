

<?php $__env->startSection('container'); ?>
<div class="container">
    <br>
    <h1>Menu Makanan</h1>
    <a href="/dashboard/menus/create" class="btn btn-primary">Tambah Menu</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Tampilan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($menu->name); ?></td>
                <td><?php echo e($menu->description); ?></td>
                <td>Rp. <?php echo e($menu->price); ?></td>
                <td>
                    <?php if($menu->image): ?>
                        <img src="<?php echo e(asset('images/' . $menu->image)); ?>" alt="Menu Image" style="width: 100px; height: auto;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/nophoto.jpg')); ?>" alt="No Image" style="width: 100px; height: auto;">
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('menus.edit', $menu->id)); ?>" class="btn btn-warning" style="padding: 1px 10px; font-size: 17px; border: none;">Edit</a>
                    <form action="<?php echo e(route('menus.destroy', $menu->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/menus/index.blade.php ENDPATH**/ ?>