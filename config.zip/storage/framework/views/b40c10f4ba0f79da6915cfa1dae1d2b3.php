<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow" data-bs-theme="dark">
  <a class="navbar-brand col-8 col-md-3 col-lg-2 me-0 px-3 text-truncate" href="#">KOPITIAM</a>
  <button class="navbar-toggler d-md-none position-absolute top-0 end-0 mt-2 me-2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <!-- <div class="navbar-nav flex-row flex-grow-1 justify-content-end pe-3">
    <div class="nav-item text-nowrap">
      
    </div>
  </div> -->
</header>
<?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/layouts/header.blade.php ENDPATH**/ ?>