

<?php $__env->startSection('container'); ?>
<div class="container-fluid bg-cover bg-blur">
    <div class="container">
        <center><h1 class="my-4">Pesan Makanan dan Minuman</h1></center>
        
        <!-- Dropdown Kategori -->
        <form action="<?php echo e(route('dashboard.orders.filter')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <select name="category" class="form-select" onchange="this.form.submit()">
                    <option value="">Pilih Kategori</option>
                    <option value="coffee" <?php echo e(request('category') == 'coffee' ? 'selected' : ''); ?>>Coffee</option>
                    <option value="non coffee" <?php echo e(request('category') == 'non coffee' ? 'selected' : ''); ?>>Non Coffee</option>
                    <option value="makanan berat" <?php echo e(request('category') == 'makanan berat' ? 'selected' : ''); ?>>Makanan Berat</option>
                    <option value="makanan ringan" <?php echo e(request('category') == 'makanan ringan' ? 'selected' : ''); ?>>Makanan Ringan</option>
                </select>
            </div>
        </form>

        <div class="row justify-content-center">
            <?php if($menus->isEmpty()): ?>
                <div class="col-12">
                    <p class="text-center">Tidak ada menu yang ditemukan.</p>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="card mb-4 shadow-sm">
                        <div class="card-img-center">
                            <img src="<?php echo e(asset('images/' . $menu->image)); ?>" class="card-img-top" alt="<?php echo e($menu->name); ?>">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-center"><?php echo e($menu->name); ?></h5>
                            <p class="card-text text-muted text-center"><?php echo e(Str::limit($menu->description, 20, '...')); ?></p>
                            <p class="card-text text-center">
                                <strong>Harga: </strong>Rp. <?php echo e(number_format($menu->price, 0, ',', '.')); ?>

                            </p>
                            <form action="<?php echo e(route('dashboard.checkout', $menu->id)); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-warning w-100" style="background-color: #155724;">
                                    <a class="text-white">Check Out</a>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\azril\coffetiam\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>