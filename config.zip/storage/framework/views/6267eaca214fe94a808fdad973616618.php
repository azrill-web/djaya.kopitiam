

<?php $__env->startSection('container'); ?>
<div class="container">
    <h1>Edit Menu: <?php echo e($menu->name); ?></h1>
    <form action="<?php echo e(route('menus.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $menu->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea class="form-control" id="description" name="description"><?php echo e(old('description', $menu->description)); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Harga</label>
            <input type="number" class="form-control" id="price" name="price" value="<?php echo e(old('price', $menu->price)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Gambar</label>
            <input type="file" class="form-control" id="image" name="image">
            <?php if($menu->image): ?>
                <img src="<?php echo e(asset('images/' . $menu->image)); ?>" alt="Menu Image" style="width: 100px; height: auto; margin-top: 10px;">
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Perbarui Menu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/menus/edit.blade.php ENDPATH**/ ?>