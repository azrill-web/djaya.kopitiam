

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Welcome back, <?php echo e(auth()->user()->name); ?></h1>
</div>
<div class="container">
    <h1>Dashboard</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
    <a href="<?php echo e(route('dashboard.images.create')); ?>" class="btn btn-primary">Upload Image</a>
    <?php endif; ?>
    <div class="row mt-4">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card mb-4 border-0"> <!-- Border dihilangkan dengan class border-0 -->
                <?php if($image->image_path): ?>
                    <img src="<?php echo e(asset('images/' . $image->image_path)); ?>" class="card-img-top" alt="Image" style="width: 100%; height: auto;">
                <?php else: ?>
                    <img src="<?php echo e(asset('images/nophoto.jpg')); ?>" alt="No Image" style="width: 100%; height: auto;">
                <?php endif; ?>
                <div class="card-body text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                        <a href="<?php echo e(route('dashboard.images.edit', $image)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('dashboard.images.destroy', $image)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this image?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/images/index.blade.php ENDPATH**/ ?>