

<?php $__env->startSection('container'); ?>
<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <h1>Konfirmasi Pesanan</h1>
    <div class="card mb-4" style="width: 100%; max-width: 500px; margin: auto;">
        <img src="<?php echo e(asset('images/' . $orderDetails['menu']->image)); ?>" class="card-img-top" alt="<?php echo e($orderDetails['menu']->name); ?>" style="width: 100%; height: auto;">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($orderDetails['menu']->name); ?></h5>
            <p class="card-text"><strong>Jumlah: </strong><?php echo e($orderDetails['quantity']); ?></p>
            <p class="card-text"><?php echo e($orderDetails['menu']->description); ?></p>
            <p class="card-text"><strong>Harga: </strong>Rp <?php echo e(number_format($orderDetails['menu']->price, 2, ',', '.')); ?></p>
            <p class="card-text"><strong>Nama Pemesan: </strong><?php echo e($orderDetails['name']); ?></p>
            <p class="card-text"><strong>Alamat: </strong><?php echo e($orderDetails['address']); ?></p>
            <p class="card-text"><strong>Nomor HP: </strong><?php echo e($orderDetails['phone']); ?></p>
            <p class="card-text"><strong>Email: </strong><?php echo e($orderDetails['email']); ?></p>
            <p class="card-text"><strong>Harga Total: </strong>Rp <?php echo e(number_format($orderDetails['grand_total'], 2, ',', '.')); ?></p>
            <p class="card-text" hidden><strong>Status: </strong><?php echo e($orderDetails['status']); ?></p>
        </div>
    </div>
    <a href="<?php echo e(route('dashboard.orders.index')); ?>" class="btn btn-primary">Kembali ke Menu</a>
    <a href="<?php echo e(route('dashboard.admin.orders.index')); ?>" class="btn btn-success">Cek Hasil Pesanan</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/orders/confirmation.blade.php ENDPATH**/ ?>