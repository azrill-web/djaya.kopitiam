

<?php $__env->startSection('container'); ?>
<div class="container">
    <br>
    <center><h1>Checkout</h1></center>
    <div class="card mb-4" style="width: 100%; max-width: 500px; margin: auto;">
        <img style="width: 100%;" src="<?php echo e(asset('images/' . $menu->image)); ?>" class="card-img-top" alt="<?php echo e($menu->name); ?>">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($menu->name); ?></h5>
            <p class="card-text"><?php echo e($menu->description); ?></p>
            <p class="card-text"><strong>Harga: </strong>Rp. <?php echo e(number_format($menu->price, 2, ',', '.')); ?></p>
        </div>
    </div>

    <form action="<?php echo e(route('dashboard.checkout.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">

        <div class="form-group">
            <label for="quantity">Jumlah</label>
            <input type="number" id="quantity" name="quantity" class="form-control" min="1" value="1" required>
        </div>

        <div class="form-group">
            <label for="name">Nama Pemesan</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="address">Alamat</label>
            <input type="text" name="address" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="phone">No. HP/WA</label>
            <input type="number" name="phone" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="form-group">
            <h5>Total Pembayaran: <span id="grandTotal">Rp. <?php echo e(number_format($menu->price, 2, ',', '.')); ?></span></h5>
            <input type="hidden" name="grand_total" id="hiddenGrandTotal" value="<?php echo e($menu->price); ?>">
        </div>

        <div class="form-group" hidden>
            <label for="status">status</label>
            <input type="text" name="status" class="form-control" value="Baru">
        </div>

        <button type="submit" class="btn btn-success">Kirim Pesanan</button>
    </form>
</div>

<script>
    const price = <?php echo e($menu->price); ?>;
    const quantityInput = document.getElementById('quantity');
    const grandTotalDisplay = document.getElementById('grandTotal');
    const hiddenGrandTotal = document.getElementById('hiddenGrandTotal');

    quantityInput.addEventListener('input', function() {
        const quantity = parseInt(quantityInput.value) || 1; // Default to 1 if input is empty
        const total = price * quantity;
        grandTotalDisplay.textContent = 'Rp. ' + total.toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        hiddenGrandTotal.value = total; // Update hidden input for grand total
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/dashboard/orders/checkout.blade.php ENDPATH**/ ?>