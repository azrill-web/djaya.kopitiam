

<?php $__env->startSection('container'); ?>
<div class="container">
    <br>
    <h1>Edit Menu Makanan</h1>
    <form action="<?php echo e(route('dashboard.menus.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Nama Menu</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($menu->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Deskripsi</label>
            <textarea name="description" class="form-control"><?php echo e($menu->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="price">Harga</label>
            <input type="number" name="price" class="form-control" step="0.01" value="<?php echo e($menu->price); ?>" required>
        </div>
        <div class="form-group">
            <label for="category">Kategori</label>
            <select name="category" class="form-control" required>
                <option value="coffee" <?php echo e($menu->category == 'coffee' ? 'selected' : ''); ?>>Coffee</option>
                <option value="non coffee" <?php echo e($menu->category == 'non coffee' ? 'selected' : ''); ?>>Non Coffee</option>
                <option value="makanan berat" <?php echo e($menu->category == 'makanan berat' ? 'selected' : ''); ?>>Makanan Berat</option>
                <option value="makanan ringan" <?php echo e($menu->category == 'makanan ringan' ? 'selected' : ''); ?>>Makanan Ringan</option>
            </select>
        </div>
        <div class="form-group">
            <label for="image">Gambar Menu:</label>
            <input type="file" class="form-control" id="image" name="image">
        </div>
        <br>
        <button type="submit" class="btn btn-success">Update Menu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\azril\coffetiam\resources\views/dashboard/menus/edit.blade.php ENDPATH**/ ?>