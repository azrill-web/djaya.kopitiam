<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">KOPITIAM</a>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\application\coba-laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>