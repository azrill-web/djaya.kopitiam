

<?php $__env->startSection('container'); ?>
<div class="nota-container">
    <div class="nota-header">
        <h2>Nota Pesanan</h2>
        <p><strong>Tanggal:</strong> <?php echo e($order->created_at->format('d-m-Y H:i')); ?></p>
    </div>
    <div class="nota-body">
        <table>
            <tr>
                <th>Nama Menu:</th>
                <td><?php echo e($order->menu ? $order->menu->name : 'Menu tidak ditemukan'); ?></td>
            </tr>
            <tr>
                <th>Jumlah:</th>
                <td><?php echo e($order->quantity); ?></td>
            </tr>
            <tr>
                <th>Harga:</th>
                <td>Rp. <?php echo e(number_format($order->grand_total, 2, ',', '.')); ?></td>
            </tr>
            <tr>
                <th>Nama Pemesan:</th>
                <td><?php echo e($order->name); ?></td>
            </tr>
            <tr>
                <th>Alamat:</th>
                <td><?php echo e($order->address); ?></td>
            </tr>
            <tr>
                <th>No. HP/WA:</th>
                <td><?php echo e($order->phone); ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo e($order->email); ?></td>
            </tr>
        </table>
    </div>
    <div class="nota-footer">
        <button onclick="window.print();" class="btn btn-primary">Cetak Nota</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\azril\coffetiam\resources\views/dashboard/admin/orders/nota.blade.php ENDPATH**/ ?>