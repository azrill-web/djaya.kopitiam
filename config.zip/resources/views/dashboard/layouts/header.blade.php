<header class="navbar navbar-expand-lg sticky-top shadow" style="background-color: #155724; padding: 10px 50px;" data-bs-theme="dark">
  <div class="container-fluid d-flex align-items-center">
    <!-- Logo dan Judul -->
    <div class="d-flex align-items-center">
      <img src="{{ asset('images/djaya.jpeg') }}" alt="" style="width: 50px; height: 50px; margin-right: 18px;">
      <h1 class="mb-0 text-white" style="font-size: 1.2rem;">DJAYA KOPITIAM</h1>
    </div>

    <!-- Toggle Button untuk Sidebar -->
    <button 
      class="navbar-toggler d-lg-none ms-auto" 
      type="button" 
      data-bs-toggle="collapse" 
      data-bs-target="#sidebarMenu" 
      aria-controls="sidebarMenu" 
      aria-expanded="false" 
      aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</header>